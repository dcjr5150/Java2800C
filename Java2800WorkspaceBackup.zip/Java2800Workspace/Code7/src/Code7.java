public class Code7 {
    public static void main(String[] args) {



    }
}
