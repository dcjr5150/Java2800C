public class Exam2 {

    public static void main(String args[]){
        
    }

}
