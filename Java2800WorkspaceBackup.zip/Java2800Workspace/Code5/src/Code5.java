import java.util.Scanner;

public class Code5 {
    public static void main( String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println(input);

        boolean finished = true;

        if(finished)
            System.out.println("I am done");
        else
            System.out.println("I am not done");
    }
}
