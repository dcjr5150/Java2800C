/*
public class HelloWorld {

    public static void main(String[] args){
        int count = 0;
        for(count = 0; count < 10; count++)
            System.out.println(count);

        System.out.println(count);
    }
}
*/

import java.util.Scanner;

public class HelloWorld{
    public static void main(String[] args ){
        float income  = 5.5f;
        Scanner input = new Scanner(System.in);
        System.out.print("enter your income please: ");
        income = input.nextFloat();
        System.out.println("the float equals" + income);
    }
}