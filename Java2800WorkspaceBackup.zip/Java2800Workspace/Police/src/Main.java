import java.util.Scanner;

public class Main {

    public static void main(String args[]){

        Name cop = createCop();

        System.out.println(cop);

    }// end of main



}// end Main
