public class BussinessMan {

    private String bussinessType;

}
