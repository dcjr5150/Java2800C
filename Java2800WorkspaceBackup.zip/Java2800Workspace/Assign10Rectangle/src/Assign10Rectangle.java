public class Assign10Rectangle {

    public static void main(String[] args) {

        Rectangle rectangle1 = new Rectangle(24,12);
        System.out.println(rectangle1);
        System.out.println(rectangle1.getPerimeter());
        System.out.println(rectangle1.getArea());

        Rectangle randomRectangle = new Rectangle();
        System.out.println(randomRectangle);
        System.out.println(randomRectangle.getPerimeter());
        System.out.println(randomRectangle.getArea());



    }



}

