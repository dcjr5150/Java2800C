public class Police {
    private Name name;
    private int badgeNumber;
    private boolean goodCop;

    public Police(Name name, int badgeNumber, boolean goodCop) {
    }

}
