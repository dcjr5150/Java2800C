public class OOPPolice {

    public static void main(String args[]){

    }

}
