// ***************************************************************************
// Written by..: Cason Lowe
// Date Written: 2/28/2018
// Purpose.....: Lecture
// ***************************************************************************

import java.util.*;

public class LectureFeb28 {
	public static void main(String[] args) {

	Cycle myCycle = new Cycle("A26", "Black", "Hunchuck", 3);
	System.out.println(myCycle);

	Motorcycle myMotorcycle = new Motorcycle("C23", "Pink", 
			"Hunchuck", 7, "Princess", "Barbie", 23, "Belt");
	System.out.println(myMotorcycle);
	

	







	} // end of Main

} // end of Class
