import java.util.Scanner;

public class Assign04_SubMethods {


    public static void fenceCalculator(){
        System.out.println("Fence");

        int area;


        System.out.print("What area do you need for your enclosure in square feet?");

        Scanner input = new Scanner(System.in);

        area = input.nextInt();






    }


}
