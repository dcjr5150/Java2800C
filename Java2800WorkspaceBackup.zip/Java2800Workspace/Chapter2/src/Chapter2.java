public class Chapter2 {
    public static void main(String[] args) {
        float grade = 4.5f;

    }
}
