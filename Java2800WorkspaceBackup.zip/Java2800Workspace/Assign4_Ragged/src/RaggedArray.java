public class RaggedArray {

    public static void main( String[] args ){
    }



}
