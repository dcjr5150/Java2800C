//Written By: Keegan Kerns 
//Date: 02/28/18
//Purpose: Exam3
//=========================

import java.util.*;
import javax.swing.*;

public class TestClass {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        char choice;


        do {
            choice = getChoice();
            switch (choice) {

                case 'A': //add a player
                    makeDate();

                    break;
                case 'B': //add a slot machine

                    break;
                case 'C': //pick a player


                    break;
                case 'D': //pick a slot machine

                    break;
                case 'F'://play slot

                    break;
                case 'Q': //Quit
                    JOptionPane.showMessageDialog(null, "Thank you for participating!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid Selection");

            }

        } while (choice != 'Q');

    }//end of main

    public static char getChoice() {
        //main menu class


        char result = 'Q';
        String inputLine, message, prompt;

        //outputting menu
        message = "A. Add a player\n";
        message += "B. Add a Slot Machine. \n";
        message += "C. Pick a Player.\n";
        message += "D. Pick a Slot Machine.\n";
        message += "F. Play Slots.\n";
        message += "Q. Quit\n";
        prompt = "Enter your selection";

        inputLine = JOptionPane.showInputDialog(message, prompt);
        inputLine = inputLine.toUpperCase();
        result = inputLine.charAt(0);

        return result;
    }//end of getChoice

    public static void makeDate() {
        int month = 0, day = 0, year = 0;
        String input, input2, input3;

        Date d1 = new Date(month, day, year);

        input = JOptionPane.showInputDialog("Enter the month:");
        month = Integer.parseInt(input);
        d1.setMonth(month);

        input3 = JOptionPane.showInputDialog("Enter the year:");
        year = Integer.parseInt(input3);
        d1.setYear(year);

        input2 = JOptionPane.showInputDialog("Enter the day:");
        day = Integer.parseInt(input2);
        d1.setDay(day, month, year);


        JOptionPane.showMessageDialog(null, d1);

    }

}//end of class
