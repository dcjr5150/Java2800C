
public class SlotMachine {

}

