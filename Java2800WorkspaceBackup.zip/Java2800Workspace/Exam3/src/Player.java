import javax.swing.JOptionPane;

public class Player {
    private Name pName;
    private Date dob;
    private double moneyBal;

    //end of the fields
    public Player(Name pName, Date dob, double moneyBal) {
        super();
        this.pName = pName;
        this.dob = dob;
        this.moneyBal = moneyBal;
    }//end of constructor


    public Name getpName() {
        return pName;
    }

    public void setpName(Name pName) {
        this.pName = pName;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public double getMoneyBal() {
        return moneyBal;
    }

    public void setMoneyBal(double moneyBal) {
        String input;
        if (moneyBal < 0) {
            JOptionPane.showMessageDialog(null, "Invalid Input");
            input = JOptionPane.showInputDialog("Enter the money the player has: ");
            moneyBal = Double.parseDouble(input);

        } else
            this.moneyBal = moneyBal;
    }

//end of setters and getters 

    public String toString() {
        return "Player [pName=" + pName + ", dob=" + dob + ", moneyBal=" + moneyBal + "]";
    }
//end of toString


}//end of class
