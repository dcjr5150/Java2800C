public class Name {
    private String first;
    private char initial;
    private String last;

    //====================(constructors)===========================
    public Name(String first, char initial, String last) {
        super();
        this.first = first;
        this.initial = initial;
        this.last = last;
    }

    //====================(Getters and setters)======================

    public String getFirst() {

        return (first);
    }

    public void setFirst(String first) {
        this.first = first;


    }

    public char getInitial() {
        return initial;
    }

    public void setInitial(char initial) {
        this.initial = Character.toUpperCase(initial);
    }

    public String getLast() {
        return (last);
    }

    public void setLast(String last) {
        this.last = last;
    }


    //==========================(toString)===========================
    public String toString() {
        String result;
        result = capitalize(first) + " ";
        if (initial == 0)
            result += capitalize(last);
        else
            result += (initial) + ". " + capitalize(last);
        return result;
    }

    //Methods
    public static String capitalize(String name) {
        return name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
    }

}//end of class
